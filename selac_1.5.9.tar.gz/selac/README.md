[![Build Status](https://travis-ci.org/bomeara/selac.svg)](https://travis-ci.org/bomeara/selac)

selac
=====

Model by O'Meara, Beaulieu, Chai, and Gilchrist for SELection on Amino acids and/or Codons
